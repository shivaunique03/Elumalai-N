"""
Python RAG Pipeline for Student Support Chatbot
Uses LangChain, ChromaDB, and Sentence-Transformers for academic implementation & report submission.
"""

import os
import json
from typing import List, Dict, Any

# Mock/Reference implementation for academic presentation
class StudentSupportRAGPipeline:
    def __init__(self, data_path: str = "../knowledge_base/campus_data.json"):
        self.data_path = data_path
        self.documents = []
        self.load_campus_documents()
        
    def load_campus_documents(self):
        """Loads and prepares campus institutional regulations."""
        if os.path.exists(self.data_path):
            with open(self.data_path, "r", encoding="utf-8") as f:
                self.documents = json.load(f)
            print(f"[Python RAG] Successfully indexed {len(self.documents)} institutional records.")
        else:
            print(f"[Python RAG] Document path {self.data_path} not found.")

    def analyze_student_sentiment(self, query: str) -> Dict[str, Any]:
        """
        Analyzes query for emotional distress, anxiety, or depression.
        In production, can use nltk.sentiment.SentimentIntensityAnalyzer or RoBERTa.
        """
        crisis_words = ["suicide", "depressed", "failing", "hopeless", "overwhelmed", "panic", "kill myself"]
        lower_q = query.lower()
        is_crisis = any(cw in lower_q for cw in crisis_words)
        
        return {
            "is_distress": is_crisis,
            "sentiment_label": "NEGATIVE_DISTRESS" if is_crisis else "NEUTRAL_INQUIRY",
            "urgency": "HIGH_PRIORITY_WELLNESS" if is_crisis else "NORMAL"
        }

    def semantic_retrieval(self, query: str, top_k: int = 2) -> List[Dict[str, Any]]:
        """
        Retrieves top-K relevant documents.
        In full PyTorch/LangChain setup, this calls:
          embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
          db = Chroma.from_documents(chunks, embeddings)
          docs = db.similarity_search(query, k=top_k)
        """
        query_words = set(query.lower().split())
        scored = []
        
        for doc in self.documents:
            text = f"{doc['title']} {doc['content']} {' '.join(doc.get('keywords', []))}".lower()
            doc_words = set(text.split())
            overlap = len(query_words.intersection(doc_words))
            scored.append((overlap, doc))
            
        scored.sort(key=lambda x: x[0], reverse=True)
        return [doc for score, doc in scored[:top_k] if score > 0]

    def ask(self, query: str) -> Dict[str, Any]:
        """Complete RAG Execution"""
        sentiment = self.analyze_student_sentiment(query)
        
        if sentiment["is_distress"]:
            return {
                "answer": "Your health and well-being come before any exam or deadline. The university counseling center is here to support you confidentially.",
                "counselor_contact": "Dr. Sneha (+91 98400 12345 Ext. 204), Health Center 1st Floor",
                "is_distress_alert": True,
                "sources": ["Student Welfare Board Wellness Charter"]
            }
            
        retrieved = self.semantic_retrieval(query)
        if retrieved:
            matched = retrieved[0]
            return {
                "answer": matched["content"],
                "source": matched["source"],
                "category": matched["category"],
                "is_distress_alert": False
            }
            
        return {
            "answer": "No official regulation found. Please visit Helpdesk Block A or email student-helpdesk@university.edu.",
            "source": ["University Central Directory"],
            "is_distress_alert": False
        }

if __name__ == "__main__":
    rag = StudentSupportRAGPipeline()
    print("Testing Query 1: Fee payment deadline")
    print(rag.ask("What is the fee payment last date?"))
    print("\nTesting Query 2: Distress check")
    print(rag.ask("I am failing everything and feeling hopeless"))
