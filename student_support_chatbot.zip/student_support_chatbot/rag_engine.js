/**
 * RAG & Sentiment Analysis Engine for AI-Powered Student Support Chatbot
 * Implements:
 * 1. Semantic Tokenization & Vector Cosine Similarity
 * 2. Campus Knowledge Base Retrieval (Top-K Chunks)
 * 3. Student Mental Distress & Sentiment Detection
 * 4. Context Grounding (Zero Hallucination Response Builder)
 */

const fs = require('fs');
const path = require('path');

// Load Knowledge Base
const KNOWLEDGE_PATH = path.join(__dirname, 'knowledge_base', 'campus_data.json');
let campusDocuments = [];

try {
  const rawData = fs.readFileSync(KNOWLEDGE_PATH, 'utf-8');
  campusDocuments = JSON.parse(rawData);
  console.log(`[RAG Engine] Successfully loaded ${campusDocuments.length} campus documents into memory.`);
} catch (err) {
  console.error('[RAG Engine] Error loading campus knowledge base:', err);
}

// Stop words to filter out
const STOP_WORDS = new Set([
  'a', 'an', 'the', 'is', 'are', 'was', 'were', 'in', 'on', 'at', 'to', 'for', 'of',
  'with', 'and', 'or', 'can', 'you', 'tell', 'me', 'what', 'when', 'how', 'where',
  'who', 'why', 'i', 'my', 'about', 'please', 'do', 'does', 'did', 'have', 'has'
]);

// Distress & Crisis Keywords
const DISTRESS_PATTERNS = [
  'kill myself', 'suicide', 'die', 'end my life', 'want to die', 'give up',
  'hopeless', 'depressed', 'depression', 'severe anxiety', 'panic attack',
  'crying', 'overwhelmed', 'cant take this', "can't take this", 'failing everything',
  'worthless', 'lost all hope', 'nobody cares', 'mental breakdown'
];

/**
 * Clean & tokenize text into semantic keywords
 */
function tokenize(text) {
  if (!text) return [];
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter(word => word.length > 2 && !STOP_WORDS.has(word));
}

/**
 * Calculate Term Frequency (TF) vector
 */
function getTfVector(tokens) {
  const tf = {};
  tokens.forEach(token => {
    tf[token] = (tf[token] || 0) + 1;
  });
  return tf;
}

/**
 * Cosine similarity between two TF vectors
 */
function cosineSimilarity(vecA, vecB) {
  let dotProduct = 0;
  let magA = 0;
  let magB = 0;

  for (const key in vecA) {
    if (vecB[key]) {
      dotProduct += vecA[key] * vecB[key];
    }
    magA += vecA[key] * vecA[key];
  }

  for (const key in vecB) {
    magB += vecB[key] * vecB[key];
  }

  magA = Math.sqrt(magA);
  magB = Math.sqrt(magB);

  if (magA === 0 || magB === 0) return 0;
  return dotProduct / (magA * magB);
}

/**
 * Analyze sentiment & distress in student message
 */
function analyzeSentimentAndDistress(query) {
  const lowerQuery = query.toLowerCase();
  let isDistressed = false;
  let matchedCrisisKeyword = null;

  for (const pattern of DISTRESS_PATTERNS) {
    if (lowerQuery.includes(pattern)) {
      isDistressed = true;
      matchedCrisisKeyword = pattern;
      break;
    }
  }

  // Basic polarity calculation
  const negativeWords = ['stress', 'fail', 'scared', 'worried', 'difficult', 'tough', 'bad', 'poor', 'urgent'];
  const positiveWords = ['good', 'great', 'thanks', 'thank you', 'clear', 'helpful', 'awesome'];

  let negCount = 0;
  let posCount = 0;

  const tokens = tokenize(query);
  tokens.forEach(t => {
    if (negativeWords.includes(t)) negCount++;
    if (positiveWords.includes(t)) posCount++;
  });

  let sentiment = 'neutral';
  if (isDistressed || negCount > posCount) sentiment = 'negative / stressed';
  else if (posCount > negCount) sentiment = 'positive';

  return {
    isDistressed,
    matchedCrisisKeyword,
    sentiment,
    urgencyLevel: isDistressed ? 'HIGH_PRIORITY_WELLNESS' : 'STANDARD'
  };
}

/**
 * Retrieve top-K relevant documents using Cosine Similarity & Keyword Overlap
 */
function retrieveContext(query, topK = 2) {
  const queryTokens = tokenize(query);
  const queryVector = getTfVector(queryTokens);

  const scoredDocs = campusDocuments.map(doc => {
    // Combine title, content, and explicit keywords for rich document vector
    const docText = `${doc.title} ${doc.content} ${(doc.keywords || []).join(' ')}`;
    const docTokens = tokenize(docText);
    const docVector = getTfVector(docTokens);

    // Compute semantic cosine score
    const cosScore = cosineSimilarity(queryVector, docVector);

    // Boost score if explicit keywords match directly
    let keywordBonus = 0;
    if (doc.keywords) {
      doc.keywords.forEach(kw => {
        if (query.toLowerCase().includes(kw.toLowerCase())) {
          keywordBonus += 0.25;
        }
      });
    }

    const finalScore = cosScore + keywordBonus;

    return {
      doc,
      score: Math.min(finalScore, 1.0)
    };
  });

  // Sort descending by relevance score
  scoredDocs.sort((a, b) => b.score - a.score);

  return scoredDocs.slice(0, topK);
}

/**
 * Generate AI Grounded Response using RAG
 */
function generateStudentResponse(userQuery) {
  const sentimentAnalysis = analyzeSentimentAndDistress(userQuery);
  const retrievedResults = retrieveContext(userQuery, 2);

  // If severe distress is detected, prioritize counseling escalation
  if (sentimentAnalysis.isDistressed) {
    const counselingDoc = campusDocuments.find(d => d.id === 'wellness-001');
    return {
      query: userQuery,
      sentiment: sentimentAnalysis,
      isDistressEscalation: true,
      answer: "I hear you, and I understand you are feeling overwhelmed right now. Please know that you are not alone, and your health and well-being come first before any exam or grade. The university provides free, confidential 1-on-1 counseling with trained professionals who are here to support you without judgment.",
      actionCard: {
        title: "Campus Wellness & Crisis Support",
        counselor: "Dr. Sneha (Health Center, 1st Floor)",
        timings: "Mon-Fri: 10:00 AM - 5:00 PM",
        crisisHotline: "+91 98400 12345 (Ext. 204)",
        emergencyNationalHelpline: "KIRAN Mental Health Helpline: 1800-599-0019 (24/7 Free & Confidential)"
      },
      sources: [counselingDoc.source],
      confidence: 0.98
    };
  }

  // Standard RAG query answering
  const bestMatch = retrievedResults[0];

  if (bestMatch && bestMatch.score > 0.20) {
    const matchedDoc = bestMatch.doc;
    return {
      query: userQuery,
      sentiment: sentimentAnalysis,
      isDistressEscalation: false,
      title: matchedDoc.title,
      category: matchedDoc.category,
      answer: matchedDoc.content,
      sources: [matchedDoc.source],
      confidence: parseFloat(bestMatch.score.toFixed(2)),
      relatedTopic: matchedDoc.title
    };
  }

  // Fallback when query is outside the database
  return {
    query: userQuery,
    sentiment: sentimentAnalysis,
    isDistressEscalation: false,
    title: "General Campus Inquiry",
    category: "General Query",
    answer: "I searched our campus official handbooks, but could not find a specific regulation matching your exact query. Please reach out to the Student Helpdesk at Helpdesk Block A (Ext. 101) or email student-helpdesk@university.edu for personalized assistance.",
    sources: ["University Central Helpdesk Directory"],
    confidence: 0.35,
    relatedTopic: "General Campus Assistance"
  };
}

module.exports = {
  generateStudentResponse,
  analyzeSentimentAndDistress,
  retrieveContext,
  campusDocuments
};
