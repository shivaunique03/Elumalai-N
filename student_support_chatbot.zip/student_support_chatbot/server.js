const express = require('express');
const cors = require('cors');
const path = require('path');
const { generateStudentResponse, campusDocuments } = require('./rag_engine');

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Health Check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    system: 'AI-Powered Student Support Chatbot',
    version: '1.0.0',
    knowledgeBaseCount: campusDocuments.length,
    timestamp: new Date().toISOString()
  });
});

// Chatbot Endpoint (RAG Query Execution)
app.post('/api/chat', (req, res) => {
  const { message } = req.body;
  if (!message || typeof message !== 'string' || message.trim().length === 0) {
    return res.status(400).json({ error: 'Message cannot be empty.' });
  }

  try {
    const result = generateStudentResponse(message.trim());
    return res.json(result);
  } catch (error) {
    console.error('Error handling /api/chat:', error);
    return res.status(500).json({
      error: 'An internal error occurred while processing the student query.'
    });
  }
});

// Knowledge Base Documents Explorer
app.get('/api/documents', (req, res) => {
  res.json({
    total: campusDocuments.length,
    documents: campusDocuments
  });
});

// Fallback to index.html
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`=======================================================`);
  console.log(`🎓 AI-Powered Student Support Chatbot Server is Online!`);
  console.log(`📡 Local URL: http://localhost:${PORT}`);
  console.log(`📚 Knowledge Base Loaded: ${campusDocuments.length} University Regulations`);
  console.log(`=======================================================`);
});
