// Frontend Logic for AI-Powered Student Support Chatbot

document.addEventListener('DOMContentLoaded', () => {
  const chatForm = document.getElementById('chatForm');
  const queryInput = document.getElementById('queryInput');
  const chatContainer = document.getElementById('chatContainer');
  const typingIndicator = document.getElementById('typingIndicator');
  const micBtn = document.getElementById('micBtn');
  const speechStatus = document.getElementById('speechStatus');
  const chipButtons = document.querySelectorAll('.chip-btn');
  
  // Modal Elements
  const viewDocsBtn = document.getElementById('viewDocsBtn');
  const docsModal = document.getElementById('docsModal');
  const closeModalBtn = document.getElementById('closeModalBtn');
  const docsList = document.getElementById('docsList');

  // Handle Quick Question Chips
  chipButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const query = btn.getAttribute('data-query');
      if (query) {
        queryInput.value = query;
        sendMessage(query);
      }
    });
  });

  // Handle Chat Form Submit
  chatForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const query = queryInput.value.trim();
    if (!query) return;
    sendMessage(query);
  });

  // Core Send Message Function
  async function sendMessage(text) {
    appendUserMessage(text);
    queryInput.value = '';
    showTyping(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text })
      });

      if (!response.ok) {
        throw new Error('Failed to fetch AI response');
      }

      const data = await response.json();
      showTyping(false);
      appendBotMessage(data);
    } catch (err) {
      console.error(err);
      showTyping(false);
      appendBotMessage({
        answer: "⚠️ Sorry, unable to connect to the campus server right now. Please ensure the server is running on http://localhost:4000.",
        sources: ["System Network Error"],
        confidence: 0
      });
    }
  }

  // Append User Bubble
  function appendUserMessage(text) {
    const msgDiv = document.createElement('div');
    msgDiv.className = 'message user-message';
    msgDiv.innerHTML = `
      <div class="avatar">👤</div>
      <div class="bubble">
        <p>${escapeHtml(text)}</p>
      </div>
    `;
    chatContainer.appendChild(msgDiv);
    scrollToBottom();
  }

  // Append Bot Bubble with RAG Verification & Distress Alerts
  function appendBotMessage(data) {
    const msgDiv = document.createElement('div');
    msgDiv.className = 'message bot-message';

    let distressHtml = '';
    if (data.isDistressEscalation && data.actionCard) {
      distressHtml = `
        <div class="distress-alert-card">
          <div class="distress-title">
            <span>🚨</span>
            <strong>${escapeHtml(data.actionCard.title)}</strong>
          </div>
          <div class="distress-details">
            <p><strong>Counselor:</strong> ${escapeHtml(data.actionCard.counselor)}</p>
            <p><strong>Available:</strong> ${escapeHtml(data.actionCard.timings)}</p>
            <p><strong>Campus Crisis Hotline:</strong> <a href="tel:${data.actionCard.crisisHotline}">${escapeHtml(data.actionCard.crisisHotline)}</a></p>
            <p><strong>National Helpline:</strong> ${escapeHtml(data.actionCard.emergencyNationalHelpline)}</p>
          </div>
          <div class="distress-actions">
            <a href="tel:+919840012345" class="call-counselor-btn">📞 Connect with Campus Counselor</a>
          </div>
        </div>
      `;
    }

    const sourceText = data.sources && data.sources.length > 0 
      ? data.sources.join(', ') 
      : 'Campus Institutional Regulations';

    const confidencePercent = Math.round((data.confidence || 0.90) * 100);

    msgDiv.innerHTML = `
      <div class="avatar">🤖</div>
      <div class="bubble">
        <p>${escapeHtml(data.answer)}</p>
        ${distressHtml}
        <div class="msg-footer">
          <span class="source-tag">📄 Source: ${escapeHtml(sourceText)}</span>
          <div class="confidence-bar">
            <span>Confidence: ${confidencePercent}%</span>
            <div class="confidence-pill" style="width: ${Math.max(confidencePercent * 0.5, 20)}px;"></div>
          </div>
          <button class="speak-btn" onclick="speakText(this)">
            🔊 Read Aloud
          </button>
        </div>
      </div>
    `;

    chatContainer.appendChild(msgDiv);
    scrollToBottom();
  }

  function showTyping(show) {
    typingIndicator.style.display = show ? 'flex' : 'none';
    if (show) scrollToBottom();
  }

  function scrollToBottom() {
    chatContainer.scrollTop = chatContainer.scrollHeight;
  }

  function escapeHtml(str) {
    if (!str) return '';
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  // Voice Input (Web Speech Recognition)
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (SpeechRecognition) {
    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.lang = 'en-US';

    micBtn.addEventListener('click', () => {
      try {
        recognition.start();
        micBtn.classList.add('recording');
        speechStatus.textContent = 'Listening to your speech...';
      } catch (err) {
        recognition.stop();
        micBtn.classList.remove('recording');
        speechStatus.textContent = '';
      }
    });

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      queryInput.value = transcript;
      speechStatus.textContent = `Captured: "${transcript}"`;
      micBtn.classList.remove('recording');
      setTimeout(() => sendMessage(transcript), 600);
    };

    recognition.onerror = () => {
      micBtn.classList.remove('recording');
      speechStatus.textContent = 'Speech input stopped.';
    };

    recognition.onend = () => {
      micBtn.classList.remove('recording');
      setTimeout(() => { speechStatus.textContent = ''; }, 3000);
    };
  } else {
    micBtn.style.opacity = '0.5';
    micBtn.title = 'Web Speech not supported in this browser';
  }

  // Knowledge Base Inspector Modal
  viewDocsBtn.addEventListener('click', async () => {
    docsModal.style.display = 'flex';
    try {
      const res = await fetch('/api/documents');
      const data = await res.json();
      docsList.innerHTML = data.documents.map(d => `
        <div class="doc-item">
          <h4>[${escapeHtml(d.category)}] ${escapeHtml(d.title)}</h4>
          <p>${escapeHtml(d.content)}</p>
          <small>📄 Citation: ${escapeHtml(d.source)}</small>
        </div>
      `).join('');
    } catch (e) {
      docsList.innerHTML = '<p>Failed to load knowledge base records.</p>';
    }
  });

  closeModalBtn.addEventListener('click', () => {
    docsModal.style.display = 'none';
  });

  window.addEventListener('click', (e) => {
    if (e.target === docsModal) docsModal.style.display = 'none';
  });
});

// Text to Speech Function
window.speakText = function(btn) {
  const bubble = btn.closest('.bubble');
  const text = bubble.querySelector('p').innerText;
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    window.speechSynthesis.speak(utterance);
    btn.innerHTML = '🔊 Speaking...';
    utterance.onend = () => { btn.innerHTML = '🔊 Read Aloud'; };
  } else {
    alert('Speech synthesis is not supported on this browser.');
  }
};
