# AI-Powered Student Support & Campus Advisory Chatbot using RAG

A modern, full-stack AI student assistance system using **Retrieval-Augmented Generation (RAG)** and **Affective Sentiment Safeguards**.

---

## 🌟 Key Features

1. **Hallucination-Free RAG Query Answering**:
   - Queries are resolved by searching indexed university circulars, fee rules, syllabus guides, and exam schedules.
   - Provides verified source citations and confidence percentages on every response.

2. **Proactive Mental Health & Distress Safeguards**:
   - Analyzes student tone and flags acute anxiety, exam panic, or depressive language.
   - Instantly triggers a confidential crisis support card connecting students directly with the university counselor.

3. **Multimodal User Interface**:
   - Voice speech input (Speech-to-Text via Web Speech API).
   - "Read Aloud" Text-to-Speech playback for bot answers.
   - Quick inquiry prompt chips for one-click questions.
   - Knowledge Base Inspector modal to explore raw vectorized documents.

---

## 🚀 How to Run the Project (Instant Demo)

### Method 1: Double-Click Launcher
Double-click `run_student_chatbot.bat` in this folder or in `e:\Priya\`.
It will start the server and open your browser automatically to:
👉 **`http://localhost:4000`**

### Method 2: Command Line
```powershell
cd e:\Priya\student_support_chatbot
node server.js
```
Open **`http://localhost:4000`** in Chrome, Edge, or Firefox.

---

## 📁 Project Structure

```
student_support_chatbot/
├── knowledge_base/
│   └── campus_data.json         # Indexed university regulations (Fees, Exams, Hostel, Library, Wellness)
├── public/
│   ├── index.html               # Modern responsive student advisory portal
│   ├── style.css                # Premium modern UI styling
│   └── app.js                   # Client-side RAG logic, voice recognition & TTS
├── python_backend/
│   ├── rag_pipeline.py          # Python LangChain / ChromaDB blueprint for report & viva
│   └── requirements.txt         # Python dependencies
├── rag_engine.js                # Core RAG retrieval engine, TF-IDF cosine similarity & sentiment analysis
├── server.js                    # Express REST API server
├── package.json                 # Node.js project manifest
├── run_chatbot.bat              # One-click startup script
└── README.md                    # Project documentation
```

---

## 🧪 Questions You Can Test Live:

1. **Tuition Fee Deadlines:** *"What is the semester fee payment deadline and fine?"*
2. **Exam Timetable:** *"When do end-semester theory exams begin?"*
3. **Hall Ticket Attendance Rule:** *"What is the attendance required to download the hall ticket?"*
4. **Merit Scholarship:** *"How can I get a merit-based scholarship?"*
5. **Library Facilities:** *"What are the Central Library working hours and borrowing rules?"*
6. **Hostel In-Timings:** *"What is the hostel gate curfew and mess timing?"*
7. **Exam Stress / Distress Test:** *"I am feeling depressed and overwhelmed about failing my exams"*
